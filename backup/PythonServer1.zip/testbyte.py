
import sys


ba = None

ba = b'ramesh'
a = b'dsad'

print( ba )