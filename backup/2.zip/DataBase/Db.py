
import threading
import pymongo as mongoConnector
import certifi


ca = certifi.where()

CONNECTION_STRING = "mongodb+srv://ramesh1234:fXtQmU86NcqQIguJ@cluster0.erdqx.mongodb.net/ITappDB?retryWrites=true&w=majority"


class Db:
    def __init__(self, threadlock: threading.Lock) -> None:

        self.dbclient = mongoConnector.MongoClient(
            CONNECTION_STRING, tlsCAFile=ca)
        self.db = self.dbclient["ITappDB"]
        self.usersdbcollection = self.db["Users"]
        self.eventsCollections = self.db['Events']
        self.CalendarEventsCollections = self.db['CalendarEvents']
        self.threadlock = threadlock

    def addAuser(self, map: dict):
        self.threadlock.acquire()
        self.usersdbcollection.insert_one(map)
        self.threadlock.release()

    def findUser(self, username: str):
        return self.usersdbcollection.find_one({'_username': username})

    def findbyEmail(self, email: str):
        return self.usersdbcollection.find_one({'_email': email})

    def getLatestEvents(self):

        List: list = []
        Dbres = self.eventsCollections.find({}, {'_id': 0})

        for item in Dbres:
            List.append(item)
        return List

    def getCalendarEvents(self):
        List = []
        Dbres = self.CalendarEventsCollections.find({}, {'_id': 0})

        for events in Dbres:
            List.append(events)
        return List
